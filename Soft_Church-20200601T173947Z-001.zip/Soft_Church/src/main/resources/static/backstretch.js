   $.backstretch("../static/Design/img/login-bg.jpg", {
      speed: 500
    });