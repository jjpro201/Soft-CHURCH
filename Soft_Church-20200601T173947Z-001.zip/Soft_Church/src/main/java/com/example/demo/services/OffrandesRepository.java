package com.example.demo.services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Offrande;

public interface OffrandesRepository extends JpaRepository<Offrande,Long>{

}
